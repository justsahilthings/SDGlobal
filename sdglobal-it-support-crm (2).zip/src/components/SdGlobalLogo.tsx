import React from 'react';

interface SdGlobalLogoProps {
  className?: string;
  size?: number;
  withWhiteSurface?: boolean;
}

export default function SdGlobalLogo({
  className = '',
  size = 36,
  withWhiteSurface = false,
}: SdGlobalLogoProps) {
  const svg = (
    <svg
      width={size}
      height={size}
      viewBox="0 0 220 220"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="SD Global Logo"
      className={withWhiteSurface ? 'block' : `shrink-0 ${className}`}
    >
      <defs>
        <linearGradient id="sdgLogoRedS" x1="15%" y1="10%" x2="85%" y2="90%">
          <stop offset="0%" stopColor="#EB2227" />
          <stop offset="55%" stopColor="#D21D22" />
          <stop offset="100%" stopColor="#B0151A" />
        </linearGradient>
        <linearGradient id="sdgLogoRedD" x1="15%" y1="15%" x2="85%" y2="85%">
          <stop offset="0%" stopColor="#E22126" />
          <stop offset="100%" stopColor="#B5171C" />
        </linearGradient>
        <linearGradient id="sdgLogoNavy" x1="10%" y1="85%" x2="90%" y2="10%">
          <stop offset="0%" stopColor="#181F2E" />
          <stop offset="60%" stopColor="#1E2638" />
          <stop offset="100%" stopColor="#283248" />
        </linearGradient>
      </defs>

      {/* Top Red Accent Arc */}
      <path
        d="M 80 42 C 98 14, 134 8, 141 42 C 133 24, 108 18, 80 42 Z"
        fill="url(#sdgLogoRedS)"
      />

      {/* Stylized Red "S" Upper Loop & Mid Bar */}
      <path
        d="M 122 49
           L 74 49
           C 56 49, 46 62, 46 80
           C 46 98, 56 111, 74 111
           L 106 111
           C 110 100, 114 89, 117 85
           L 80 85
           C 74 85, 71 81, 71 76
           C 71 71, 74 68, 80 68
           L 120 68
           Z"
        fill="url(#sdgLogoRedS)"
      />

      {/* Stylized Red "S" Lower Slanted Bar */}
      <path
        d="M 65 117 L 103 117 L 86 144 L 46 144 Z"
        fill="url(#sdgLogoRedS)"
      />

      {/* Stylized Red "D" */}
      <path
        d="M 134 59
           L 145 59
           C 163 59, 173 74, 173 96
           C 173 119, 162 146, 146 154
           C 150 132, 151 112, 149 95
           C 148 87, 144 82, 137 82
           L 134 82
           L 132 161
           L 120 169
           C 122 135, 131 94, 134 59
           Z"
        fill="url(#sdgLogoRedD)"
      />

      {/* Central Sweeping Dark Navy Crescent Swoosh */}
      <path
        d="M 41 117
           C 32 150, 42 183, 62 183
           C 89 183, 129 124, 135 66
           C 138 38, 128 24, 111 24
           C 123 30, 127 46, 123 68
           C 115 114, 78 162, 57 162
           C 44 162, 38 144, 41 117
           Z"
        fill="url(#sdgLogoNavy)"
      />

      {/* Lower Right Sweeping Dark Navy Swoosh */}
      <path
        d="M 119 175
           C 144 172, 169 138, 177 83
           C 173 134, 159 173, 143 183
           L 119 183
           Z"
        fill="url(#sdgLogoNavy)"
      />

      {/* "GLOBAL" Wordmark */}
      <text
        x="97"
        y="183"
        textAnchor="middle"
        fontFamily="'Public Sans', 'Plus Jakarta Sans', Arial, sans-serif"
        fontSize="13.5"
        fontWeight="600"
        letterSpacing="1.2"
        fill="#B91C1C"
      >
        GLOBAL
      </text>
    </svg>
  );

  if (withWhiteSurface) {
    return (
      <span
        className={`inline-flex items-center justify-center rounded-lg bg-white p-0.5 shadow-sm ring-1 ring-slate-200/80 shrink-0 ${className}`}
      >
        {svg}
      </span>
    );
  }

  return svg;
}
